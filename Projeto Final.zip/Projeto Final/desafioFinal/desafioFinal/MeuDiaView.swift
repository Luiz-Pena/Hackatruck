//
//  MeuDiaView.swift
//  desafioFinal
//
//  Created by Turma02-Backup on 27/02/25.
//

import SwiftUI

struct MeuDiaView: View {
    var body: some View {
    
        VStack {
            
            HStack {
                
                ZStack {
                    Rectangle()
                        .fill(.gray)
                        .ignoresSafeArea(.all)
                    Text("Meu Dia")
                        .foregroundColor(.white)

                }
                Spacer()
            }
            
            VStack {
                
                Image(systemName: "play")
                
            }
        }
    }
}

#Preview {
    MeuDiaView()
}
