//
//  desafioFinalApp.swift
//  desafioFinal
//
//  Created by Turma02-Backup on 27/02/25.
//

import SwiftUI

@main
struct desafioFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
