//
//  Desafio_01App.swift
//  Desafio 01
//
//  Created by Turma02-Backup on 05/02/25.
//

import SwiftUI

@main
struct Desafio_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
