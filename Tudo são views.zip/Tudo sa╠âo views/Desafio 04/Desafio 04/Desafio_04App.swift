//
//  Desafio_04App.swift
//  Desafio 04
//
//  Created by Turma02-Backup on 07/02/25.
//

import SwiftUI

@main
struct Desafio_04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
