//
//  Perfil_InstaApp.swift
//  Perfil Insta
//
//  Created by Turma02-Backup on 06/02/25.
//

import SwiftUI

@main
struct Perfil_InstaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
