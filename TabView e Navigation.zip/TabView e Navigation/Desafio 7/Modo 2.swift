//
//  Modo 2.swift
//  Desafio 7
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct Modo_2: View {
    var body: some View {
        
        NavigationStack {
            
            VStack {
                Text ("")
                Text ("Bem vindo, ")
                NavigationLink (destination: Modo_2_2()) {
                    Text ("Acessar Tela")
                }
            }
            
        }
    }
}

#Preview {
    Modo_2()
}
