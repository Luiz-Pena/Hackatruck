//
//  Modo 2:2.swift
//  Desafio 7
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct Modo_2_2: View {
    var body: some View {
        Text("Volte ")
    }
}

#Preview {
    Modo_2_2()
}
