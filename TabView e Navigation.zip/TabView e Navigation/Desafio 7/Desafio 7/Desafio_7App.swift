//
//  Desafio_7App.swift
//  Desafio 7
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

@main
struct Desafio_7App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
