//
//  ContentView.swift
//  Desafio 7
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var Sheet = false
    
    var body: some View {
        NavigationStack {
            
            VStack {
                Image("Image")
                    .resizable()
                    .scaledToFit()
            }
            
            Spacer()
            
            NavigationLink (destination: Modo_1()) {
                
                Text ("Modo 1")
                
            }
            
            Button ("Modo 3") {
                Sheet = true
            }.sheet(isPresented: $Sheet) {
                ZStack {
                    Rectangle()
                        .fill(.gray)
                        .ignoresSafeArea(.all)
                    Text("Sheet View")
                        .foregroundColor(.white)
                    
                    Spacer()
                    Text ("Nome: ")
                    Text ("Sobrenome")
                    
                    Spacer()
                }
            }
            
            Spacer()
            
            
        }
    }
}

#Preview {
    ContentView()
}
