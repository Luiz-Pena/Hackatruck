//
//  Modo 1.swift
//  Desafio 7
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct Modo_1: View {
    var body: some View {
        VStack {
            Text ("Modo 1")
            
            Spacer ()
                
            VStack {
                Text ("Nome: ")
                Text ("Sobrenome: ")
            }
            
        }
    }
}

#Preview {
    Modo_1()
}
