//
//  ContentView.swift
//  Desafio 06
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ROSA()
                .tabItem {
                    Label ("Rosa", systemImage: "paintbrush")
                }
            
            AZUL()
                .tabItem {
                    Label ("Azul", systemImage: "paintbrush.pointed")
                }
            
            CINZA()
                .tabItem {
                    Label ("Cinza", systemImage:"paintpalette")
                }
            
            LISTA()
                .tabItem {
                    Label ("Lista", systemImage: "list.bullet")
                }
            
            
        }
    }
}

#Preview {
    ContentView()
}
