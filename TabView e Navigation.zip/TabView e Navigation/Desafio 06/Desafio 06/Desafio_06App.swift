//
//  Desafio_06App.swift
//  Desafio 06
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

@main
struct Desafio_06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
