//
//  AZUL.swift
//  Desafio 06
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct AZUL: View {
    var body: some View {
        ZStack {
            Color.blue.edgesIgnoringSafeArea (.top)
            Circle()
                .frame(width: 270.0, height: 270.0)
            
            
            Image(systemName: "paintbrush.pointed")
                .resizable()
                .frame(width: 200.0, height: 200.0)
                .foregroundColor(.blue)
            
        }
        
    }
}

#Preview {
    AZUL()
}
