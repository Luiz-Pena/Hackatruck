//
//  ROSA.swift
//  Desafio 06
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct ROSA: View {
    var body: some View {
        ZStack {
            Color.pink.edgesIgnoringSafeArea (.top)
            Circle()
                .frame(width: 270.0, height: 270.0)
            
            
            Image(systemName: "paintbrush")
                .resizable()
                .frame(width: 200.0, height: 200.0)
                .foregroundColor(.pink)
            
        }
        
    }
}


#Preview {
    ROSA()
}
