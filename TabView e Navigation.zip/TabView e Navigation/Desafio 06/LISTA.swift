//
//  LISTA.swift
//  Desafio 06
//
//  Created by Turma02-Backup on 11/02/25.
//

import SwiftUI

struct LISTA: View {
    var body: some View {
        VStack {
            
            HStack {
                Text ("List")
                Spacer()
            }
            .padding()
                
            
            HStack {
                Text ("Item")
                Spacer()
                Image(systemName: "paintbrush")
            }
            .padding()
            
            HStack {
                Text ("Item")
                Spacer()
                Image(systemName: "paintbrush.pointed")
            }
            .padding()

            HStack {
                Text ("Item")
                Spacer()
                Image(systemName: "paintpalette")
            }
            .padding()

            Spacer()
            
        }
    }
}

#Preview {
    LISTA()
}
