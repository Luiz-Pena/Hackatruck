//
//  Desafio_5App.swift
//  Desafio 5
//
//  Created by Turma02-Backup on 10/02/25.
//

import SwiftUI

@main
struct Desafio_5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
