//
//  ContentView.swift
//  Desafio 10
//
//  Created by Turma02-Backup on 17/02/25.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var vm = GatinhoViewModel()
    var body: some View {
        
        NavigationStack {
            
            ScrollView {
                
                ForEach (vm.arrayFotinhas) { foto in
                    
                    NavigationLink(destination: TelaAlt(fotoatual: foto.url), label: {
                        ZStack {
                            AsyncImage(url: URL(string: foto.url)!) { image in
                                image.resizable()
                            } placeholder: { ProgressView() }
                                .scaledToFit()
                    }
                    })
                
                
                
            }
            }
            .onAppear(){vm.fetch()
            }
        }
        
    }
}

#Preview {
    ContentView()
}
