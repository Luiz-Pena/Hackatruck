//
//  Model.swift
//  Desafio 10
//
//  Created by Turma02-Backup on 17/02/25.
//

import Foundation

struct Fotinha: Decodable, Identifiable {
    var id: String
    var url: String
    var width: Double
    var height: Double
}

struct Curiosidade {
    var textopt: String
}

struct CuriText : Decodable  {
    var data: [String]
}
