//
//  TelaAlt.swift
//  Desafio 10
//
//  Created by Turma02-Backup on 17/02/25.
//

import SwiftUI

struct TelaAlt: View {
    
    var fotoatual: String
    
    var body: some View {
        VStack {
            AsyncImage(url: URL(string: fotoatual)) { image in
                                            image.resizable()
                                        } placeholder: { ProgressView() }
                                            .scaledToFit()
            //
        }
    }
}

#Preview {
    TelaAlt(fotoatual: "https://cdn2.thecatapi.com/images/e83.jpg")
}
