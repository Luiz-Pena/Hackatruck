//
//  GatinhoViewModel.swift
//  Desafio 10
//
//  Created by Turma02-Backup on 17/02/25.
//

import Foundation

class GatinhoViewModel: ObservableObject {
    @Published var arrayFotinhas: [Fotinha] = []
    @Published var textoCuriosidade: CuriText?
    
    func fetch(){
        var url = "https://api.thecatapi.com/v1/images/search?limit=10"
        
        var task = URLSession.shared.dataTask(with: URL(string: url)!){ dados, _, error in
            
            do {
                self.arrayFotinhas = try JSONDecoder().decode([Fotinha].self, from: dados!)
            } catch {
                print (error)
            }
            
        }
        task.resume()
    }
    
    func fetch2(){
        var url = "https://meowfacts.herokuapp.com/?lang=por"
        
        var task = URLSession.shared.dataTask(with: URL(string: url)!){ dados, _, error in
            
            do {
                self.textoCuriosidade = try JSONDecoder().decode(CuriText.self, from: dados!)
                
            } catch {
                print (error)
            }
            
        }
        task.resume()
    }
    
    
    
}
