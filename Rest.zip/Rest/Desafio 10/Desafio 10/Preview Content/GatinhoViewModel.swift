//
//  GatinhoViewModel.swift
//  Desafio 10
//
//  Created by Turma02-Backup on 17/02/25.
//

import Foundation

class GatinhoViewModel: ObservableObject {
    @Published var arrayFotinhas: [Fotinha] = []
    
    func fetch(){
        var url = "https://api.thecatapi.com/v1/images/search?limit=10"
        
        var task = URLSession.shared.dataTask(with: URL(string: url)!){ dados, _, error in
            
            do {
                self.arrayFotinhas = try JSONDecoder().decode([Fotinha].self, from: dados!)
                print (self.arrayFotinhas.count)
            } catch {
                print (error)
            }
            
        }
        
        task.resume()
        
    }
}
