//
//  Desafio_10App.swift
//  Desafio 10
//
//  Created by Turma02-Backup on 17/02/25.
//

import SwiftUI

@main
struct Desafio_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
