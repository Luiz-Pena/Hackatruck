//
//  Desafio_09App.swift
//  Desafio 09
//
//  Created by Turma02-Backup on 13/02/25.
//

import SwiftUI

@main
struct Desafio_09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
