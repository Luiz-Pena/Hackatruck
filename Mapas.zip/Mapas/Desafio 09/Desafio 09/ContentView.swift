//
//  ContentView.swift
//  Desafio 09
//
//  Created by Turma02-Backup on 13/02/25.
//

import SwiftUI
import MapKit

struct Location: Hashable {
    let nome: String
    let foto: String
    let descricao: String
    let latitude: Double
    let longitude: Double
}
    
struct ContentView: View {
    
    let location = [
        Location(nome: "Taubate", foto: "https://upload.wikimedia.org/wikipedia/pt/1/10/Grávida_de_Taubaté.jpg", descricao: "A maior gravida de Taubate que nao deu a luz a trigemios e nao engravidou", latitude: -23.01907843435788, longitude: -45.57248243403549),
        
        Location(nome: "Varginia", foto: "https://s2-g1.glbimg.com/k2niLwW5E-XzC4vWOVK3E8jgy0w=/0x0:1193x783/600x0/smart/filters:gifv():strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2023/y/A/RXL8qXRkWW81Z0IfsVwA/estatua-et-de-varginha-3.jpeg", descricao: "Area 51 brasileira", latitude: -21.53899587336939, longitude:-45.43686946622145),
        
        Location(nome: "Sumaré", foto: "https://cdn-images.dzcdn.net/images/cover/510cf489de1d66f07b11523e3ecd593e/0x1900-000000-80-0-0.jpg", descricao: "Cidade da maior influenciadora nordestina, bisexual e plus size", latitude: -22.824384194051163, longitude: -47.27038972396093 ),
        
        //Location(nome: " ", foto: " ", descricao: " ", latitude: , longitude: ),
        
        //Location(nome: " ", foto: " ", descricao: " ", latitude: , longitude: )
        
         ]
    @State var CidadeAtual =  Location(nome: "", foto: "", descricao: "", latitude: -15.789879951433026, longitude: -47.88263529428804)
    @State private var Sheet = false
    @State var position =
    
    MapCameraPosition.region (
        MKCoordinateRegion (
            center: CLLocationCoordinate2D(latitude: -15.78987995143302,  longitude: -47.88263529428804),
            span: MKCoordinateSpan(latitudeDelta: 20, longitudeDelta: 20)
        )
    )
    
    var body: some View {
        
        VStack {
           
            Picker("Texto", selection: $CidadeAtual) {
                ForEach (location, id: \.self){ item in
                    Text (item.nome)
                }
            }
            
            Map (position: $position) {
                ForEach (location, id: \.self) {
                    item in
                    
                    Annotation (item.nome, coordinate: CLLocationCoordinate2D(latitude: item.latitude, longitude: item.longitude)) {
                        
                        Button  {
                            Sheet = true
                        } label: {
                            Image(systemName: "mappin")
                        }
 .sheet(isPresented: $Sheet) 
                            }
                                        
                    }
                }
                
                
            }
            .ignoresSafeArea()
            
        }
        
            
        }
        
        
        
        
}

#Preview {
    ContentView()
}
