//
//  D2App.swift
//  D2
//
//  Created by Turma02-Backup on 05/02/25.
//

import SwiftUI

@main
struct D2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
