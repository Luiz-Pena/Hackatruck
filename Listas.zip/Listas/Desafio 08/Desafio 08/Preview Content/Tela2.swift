//
//  Tela2.swift
//  Desafio 08
//
//  Created by Turma02-Backup on 12/02/25.
//

import SwiftUI

struct Tela2: View {
    
    var name: String
    var artist: String
    var capa: String
    
    var body: some View {
        VStack {
            
            Spacer()
            
            AsyncImage(url: URL(string: capa))
                { image in
                image.resizable()
            } placeholder: {
                ProgressView()
            }
            .frame(width: 50, height: 50)
            
            Text(name)
            Text(artist)
            
            
            Spacer()
            
            HStack (spacing: 30) {
                Image(systemName: "shuffle")
                    .resizable()
                    .frame(width: 30.0, height: 30.0)
                
                
                Image(systemName: "backward.end.fill")
                    .resizable()
                    .frame(width: 30.0, height: 30.0)
                
                Image(systemName: "play.fill")
                    .resizable()
                    .frame(width: 50.0, height: 50.0)
                
                Image(systemName: "forward.end.fill")
                    .resizable()
                    .frame(width: 30.0, height: 30.0)
                
                Image(systemName: "repeat")
                    .resizable()
                    .frame(width: 30.0, height: 30.0)
            }
            .frame(width: 300.0, height: 100.0)
            
            Spacer()
        }
    }
}

#Preview {
    Tela2(name: "Lovers Rock" , artist: "TV Girl", capa: " ")
}
