//
//  Desafio_08App.swift
//  Desafio 08
//
//  Created by Turma02-Backup on 12/02/25.
//

import SwiftUI

@main
struct Desafio_08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
