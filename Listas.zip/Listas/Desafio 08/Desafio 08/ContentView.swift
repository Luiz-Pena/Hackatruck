//
//  ContentView.swift
//  Desafio 08
//
//  Created by Turma02-Backup on 12/02/25.
//

import SwiftUI

struct ContentView: View {
    
    struct Song: Identifiable {
        var id: Int
        var name: String
        var artist: String
        var capa: String
    }
    
    var ArrayMusicas = [
        Song(id:1, name: "Lovers Rock" , artist: "TV Girl", capa: " "),
        Song(id:2 , name: "Trainwreck" , artist: "Demi Lovato", capa: " "),
        Song(id:3 , name: "Set Me Free" , artist: "Twice", capa: " "),
        Song(id:4 , name: "Radioactive" , artist: "MARINA", capa: " "),
        Song(id:5 , name: "Star" , artist: "LOONA", capa: " "),
        Song(id:6 , name: "Sneakers" , artist: "ITZY", capa: " "),
        Song(id:7 , name: "No Biggie" , artist: "ITZY", capa: " "),
        Song(id:8 , name: "How To Get The Girl" , artist: "Taylor Swift", capa: " "),
        Song(id:9 , name: "Sunflower" , artist: "Ross Malone, Swae Lee", capa: " "),
        Song(id:10 , name: "Push & Pull" , artist: "Twice", capa: " ")
    ]
    
    
    
    var body: some View {
            NavigationStack {
                ScrollView {
                    Image(systemName: "music.note")
                    
                    ForEach (ArrayMusicas) { item in
                        NavigationLink (destination: Tela2(name: item.name, artist: item.artist, capa: item.capa)) {
                            
                            HStack {
                                
                                AsyncImage(url: URL(string: item.capa)) { image in
                                    image.resizable()
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(width: 50, height: 50)
                                
                                VStack(alignment: .leading) {
                                    Text (item.name)
                                    Text (item.artist)
                                }
                                
                                Spacer()
                                
                                Image(systemName: "ellipsis")
                            }
                        }
                    }
                    
                }
            }
            
        }
    }

#Preview {
    ContentView()
}
